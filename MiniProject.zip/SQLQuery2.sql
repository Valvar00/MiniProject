SELECT * 
FROM drug_deaths
WHERE ID = '1'

SELECT *
FROM [rdu-weather-history_c]
WHERE temperaturemin = -20

SELECT *
FROM [rdu-weather-history_c]

SELECT *
FROM dimDeathCity
WHERE city = 'd'

SELECT *
FROM deaths_by_drugs




SELECT * FROM AdventureWorks2014.Production.Product

---UsedSubstancesQuantity COUNT AVG SUM
---VolumeOfUsedSubstances
---AmountMeasureCode
ALTER TABLE deaths_by_drugs DROP COLUMN  [??????? 26]

SELECT Drug

ALTER TABLE deaths_by_drugs ADD ID INT NOT NULL PRIMARY KEY IDENTITY(1,1) 

SELECT * FROM DrugDeath

'