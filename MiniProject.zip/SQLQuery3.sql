---dimResidenceCity---
SELECT city, city_ascii, state_name, county_name, lat, lng, population, density, military, incorporated, timezone
		INTO dimResidenceCity
FROM drug_deaths AS dd
LEFT JOIN residence_death_drug_city AS c
ON dd.ResidenceCity = c.city AND dd.ResidenceCounty = c.county_name
WHERE ResidenceCity IS NOT NULL and city != ' '
GROUP BY city, city_ascii, state_name, county_name, lat, lng, population, density, military, incorporated, timezone


---dimDeathCity---
SELECT city, city_ascii, state_name, county_name, lat, lng, population, density, military, incorporated, timezone
		INTO dimDeathCity
FROM drug_deaths AS dd
LEFT JOIN residence_death_drug_city AS c
ON dd.DeathCity = c.city AND dd.DeathCounty = c.county_name
WHERE city IS NOT NULL
GROUP BY city, city_ascii, state_name, county_name, lat, lng, population, density, military, incorporated, timezone



---dimResidenceCounty---
SELECT county_name, state_name, county_fips
		INTO dimResidenceCounty
FROM drug_deaths AS dd
LEFT JOIN residence_death_drug_county_2 AS c
ON dd.ResidenceCounty = c.county_name
GROUP BY county_name, state_name, county_fips


---dimDeathCounty---
SELECT county_name, state_name, county_fips
	INTO dimDeathCounty
FROM drug_deaths AS dd
LEFT JOIN residence_death_drug_county_2 AS c
ON dd.DeathCounty = c.county_name
WHERE county_name IS NOT NULL
GROUP BY county_name, state_name, county_fips





SELECT date, day, month, year, CONVERT(REAL, temperaturemin) / 100 AS temperaturemin,
			CONVERT(REAL, temperaturemax) / 100 AS temperaturemax,
			CONVERT(REAL, precipitation) / 100 AS precipitation,
		fog, fogheavy, mist, rain, fogground, ice, glaze, snow, drizzle, freezingrain, smokehaze, thunder, highwind, hail,
		blowingsnow, dust, freezingfog
		INTO WeatherData
FROM [dbo].[rdu-weather-history_c] AS w




SELECT * 
FROM (
SELECT ResidenceCity, ResidenceCounty
FROM drug_deaths
WHERE ResidenceCity != ' ' AND ResidenceCounty != ' '
GROUP BY ResidenceCity, ResidenceCounty
) AS temp
INNER JOIN residence_death_drug_city AS c
ON temp.ResidenceCity = c.city AND temp.ResidenceCounty = c.county_name



SELECT DeathCity, DeathCounty, COUNT(*)
FROM drug_deaths
WHERE DeathCity != ' ' AND DeathCounty != ' '
GROUP BY DeathCity, DeathCounty


SELECT *
FROM residence_death_drug_city
WHERE city = 'Bethel'

SELECT *
FROM drug_deaths
WHERE ResidenceCity != ' ' AND ResidenceCounty != ' ' AND DeathCity = 'Bethel'


