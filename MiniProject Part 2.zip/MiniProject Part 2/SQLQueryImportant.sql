UPDATE drug_death
	SET ResidenceCity='No Info'
	WHERE ResidenceCity IS NULL

UPDATE drug_death
	SET Residencecounty='No Info'
	WHERE Residencecounty IS NULL

UPDATE drug_death
	SET Deathcity='No Info'
	WHERE Deathcity IS NULL

UPDATE drug_death
	SET Deathcounty='No Info'
	WHERE Deathcounty IS NULL

ALTER TABLE drug_death ALTER COLUMN Deathcounty VARCHAR(255) NOT NULL
ALTER TABLE drug_death ALTER COLUMN Deathcity VARCHAR(255) NOT NULL

ALTER TABLE drug_death ALTER COLUMN Residencecounty VARCHAR(255) NOT NULL
ALTER TABLE drug_death ALTER COLUMN ResidenceCity VARCHAR(255) NOT NULL

ALTER TABLE drug_death ALTER COLUMN ID FLOAT NOT NULL;

DELETE city_copy
WHERE county_name IS NULL

ALTER TABLE drug_death
ADD PRIMARY KEY (ID);

WITH cte AS (
    SELECT 
      	city, 
       	state_name, 
       	county_name,
	lat, 
	lng,
	population,
	density,
	military,
	incorporated,
	timezone,
        ROW_NUMBER() OVER (
            PARTITION BY 
	city,
	county_name
            ORDER BY 
	county_name,
	city
        ) row_num
     FROM 
        city_copy
)
DELETE FROM cte
WHERE row_num > 1;

ALTER TABLE city_copy ALTER COLUMN county_name VARCHAR(255) NOT NULL
ALTER TABLE city_copy ALTER COLUMN city VARCHAR(255) NOT NULL

ALTER TABLE city_copy
ADD CONSTRAINT PK_city_county PRIMARY KEY (city, county_name);

ALTER TABLE drug_death WITH NOCHECK
   ADD CONSTRAINT FK_drug_death_city
   FOREIGN KEY(ResidenceCity, Residencecounty)
   REFERENCES city_copy(city,county_name)

ALTER TABLE drug_death WITH NOCHECK
   ADD CONSTRAINT FK_drug_death_death_city
   FOREIGN KEY(Deathcity, Deathcounty)
   REFERENCES city_copy(city,county_name)