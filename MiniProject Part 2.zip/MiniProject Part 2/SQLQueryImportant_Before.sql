alter table city_copy add constraint city_1 unique(city);

SELECT
	city,
	county_name,
    COUNT(*) occurrences
FROM city_copy
GROUP BY
	county_name,
	city
HAVING 
    COUNT(*) > 1;

WITH cte AS (
    SELECT 
        city, 
        ID, 
        state_name, 
        county_name,
		lat, 
		lng,
		population,
		density,
		military,
		incorporated,
		timezone,
        ROW_NUMBER() OVER (
            PARTITION BY 
				city,
				county_name
            ORDER BY 
			county_name,
			city
        ) row_num
     FROM 
        city_copy
)
DELETE FROM cte
WHERE row_num > 1;

ALTER TABLE drug_death ADD Residence_city VARCHAR(255) NOT NULL DEFAULT 0;
ALTER TABLE drug_death ADD Residence_county VARCHAR(255) NOT NULL DEFAULT 0;

ALTER TABLE drug_death WITH NOCHECK
   ADD CONSTRAINT FK_drug_death_residence_city
   FOREIGN KEY(ResidenceCity, Residencecounty)
   REFERENCES city_copy(city,county_name)

ALTER TABLE drug_death WITH NOCHECK
   ADD CONSTRAINT FK_drug_death_death_city
   FOREIGN KEY(Deathcity, Deathcounty)
   REFERENCES city_copy(city,county_name)

ALTER TABLE city_copy
ADD CONSTRAINT PK_city_county PRIMARY KEY (city, county_name);

ALTER TABLE city_copy ALTER COLUMN county_name VARCHAR(255) NOT NULL
ALTER TABLE city_copy ALTER COLUMN city VARCHAR(255) NOT NULL

ALTER TABLE drug_death ALTER COLUMN Residencecounty VARCHAR(255) NOT NULL
ALTER TABLE drug_death ALTER COLUMN ResidenceCity VARCHAR(255) NOT NULL
ALTER TABLE drug_death ALTER COLUMN Deathcounty VARCHAR(255) NOT NULL
ALTER TABLE drug_death ALTER COLUMN Deathcity VARCHAR(255) NOT NULL


UPDATE drug_death
	SET ResidenceCity='No Info'
	WHERE ResidenceCity IS NULL

UPDATE drug_death
	SET Residencecounty='No Info'
	WHERE Residencecounty IS NULL

UPDATE drug_death
	SET Deathcity='No Info'
	WHERE Deathcity IS NULL

UPDATE drug_death
	SET Deathcounty='No Info'
	WHERE Deathcounty IS NULL

SELECT ResidenceCity
FROM drug_death
WHERE ResidenceCity IS NULL


SELECT ResidenceCity,Residencecounty,city,county_name
FROM city_copy,drug_death
WHERE ResidenceCity=city AND Residencecounty=county_name